# ACML - ANN

## Execution instructions
* make sure to have the dependencies 'numpy' and 'matplotlib' installed
* run 'train.py' with python version 3.7.4

## Development instructions:
* Download and install anaconda (for python version 3):
https://www.anaconda.com/download/#windows

* Download and install pycharm:
https://www.jetbrains.com/pycharm/download/#section=windows

